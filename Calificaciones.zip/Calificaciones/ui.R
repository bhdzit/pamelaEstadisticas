library(shiny)
library(shinydashboard)
shinyUI(dashboardPage(title = "Calificaciones ITSOEH", skin = "blue",
                      dashboardHeader(title = "Calificaciones"),
                      dashboardSidebar(
                        sidebarMenu(  
                          HTML(paste0(#imágen de Netflix y dirección a la página oficial
                          "<br>",
                          "<a href='https://www.netflix.com/' target='_blank'><img style = 'display: block; margin-left: auto; margin-right: auto;' src='https://sic.cultura.gob.mx/images/62464' width = '186'></a>",
                          "<br>"
                        )),
                          menuItem("Datos"),
                          fileInput("file","Sube los archivos correspondientes", multiple = TRUE),#
                          checkboxInput(inputId = 'header', label = 'Header', value = TRUE),
                          checkboxInput(inputId = "stringAsFactors", "stringAsFactors", FALSE),
                          radioButtons(inputId = 'sep', label = 'Separator', choices = c(Comma=',',Semicolon=';',Tab='\t', Space=''), selected = ','),
                          uiOutput("selectfile"),
                          menuSubItem("datos sin graficar", tabName = "datos" ,icon = shiny::icon("database")),
                          menuItem("Visualizacion de Datos"),
                          menuSubItem("datos en gráfica", tabName = "visualizacion" ,icon = shiny::icon("laptop"))
                        ) 
                      ),
                      dashboardBody(
                        tabItems(
                          tabItem(tabName = "datos",
                                  uiOutput("tb")           
                          ),
                          tabItem(tabName = "visualizacion",
                                  
                          )
                        )
                      )
)


)