
library(shiny)
options(shiny.maxRequestSize = 30*1024^2)# cambiar el límtite del tamaño del archivo a 30mb

shinyServer(function(input,output) {
  
  output$filedf <- renderTable({#nombre y direccion de los archivos
    if(is.null(input$file)){return ()}
    input$file
  })
  
  output$filedf2 <- renderTable({#tabla con las dirrecciones de los archvios subidos
    if(is.null(input$file)){return ()}
    input$file$datapath
  })
  

  output$selectfile <- renderUI({# seleccionar el archivo
    if(is.null(input$file)) {return()}
    list(hr(), 
         helpText("Selecciona los archivos"),
         selectInput("Select", "Select", choices=input$file$name)
    )
    
  })

  output$table <-renderPrint({ 
    if(is.null(input$file)){return()}#nombre del archivo = al select
    r <- read.table(file=input$file$datapath[input$file$name==input$Select], sep=input$sep, header = input$header, stringsAsFactors = input$stringAsFactors)
    output$tablaUsuario <- DT::renderDataTable(r)#leer tablas segun la selcción
    
  })
  
  
  
  

  output$tb <- renderUI({
    if(is.null(input$file)) {return()}
    else
      tabsetPanel(#mostrar primero las dos tablas
        tabPanel("Datos de los archivos", tableOutput("filedf"), tableOutput("filedf2")),
        tabPanel("Tabla",verbatimTextOutput("table"),  DT::dataTableOutput("tablaUsuario")))
    #mostrar tablas
  })
  
  
  
  
  
  
})